<?php

    
    $con=new mysqli("localhost","root","","tifflunbox");
    
    $mid=$_POST['email_id'];
    $otp=$_POST['otp'];
    
    /*$qu="SELECT otp_no FROM otp WHERE email_id='$mid'";
    
    $pp=$con->query($qu);
    
    $ff=$pp->fetch_object();
    
    
		echo $otp_no = $ff->otp_no;*/
    

error_reporting(E_ALL);
require("PHPMailer_5.2.4 4/class.phpmailer.php");

$mail = new PHPMailer();
$mail->IsSMTP(); // set mailer to use SMTP
$mail->SMTPDebug = 2;

   
    
$mail->From = "nsurti8@gmail.com";
$mail->FromName = "Tifflunbox";
$mail->Host = "smtp.gmail.com"; // specif smtp server
$mail->SMTPSecure= "ssl"; // Used instead of TLS when only POP mail is selected
$mail->Port =465; //465.. Used instead of 587 when only POP mail is selected

$mail->SMTPAuth = true;

$mail->Username = "nsurti8@gmail.com"; // SMTP username
$mail->Password = "8153003181"; // SMTP password
$mail->AddAddress("$mid", "Tifflunbox"); //replace myname and mypassword to yours
$mail->AddReplyTo("$mid", "Tifflunbox");

$mail->WordWrap = 50; // set word wrap
//$mail->AddAttachment("c:\\temp\\js-bak.sql"); // add attachments
//$mail->AddAttachment("c:/temp/11-10-00.zip");


$mail->IsHTML(true); // set email format to HTML
$mail->Subject = 'plz enter your otp and conform your order';
$mail->Body = $otp;

if($mail->Send()) {echo "Send mail successfully";}
else {echo "Send mail fail";} 
    
?>
