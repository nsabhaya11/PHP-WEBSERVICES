<?php
    echo "OK";
    $dt = [];
    $con=new mysqli("localhost","root","","tifflunbox");
    $data=file_get_contents('php://input');
    $dt = json_decode($data);
    
    print_r($dt);
    echo count($dt);
    for($i = 0 ; $i < count($dt);$i++)
    {
        
        $temp = $dt[$i];
       
        $item_name = $temp->item_name;
        $item_price = $temp->item_price;
        $order_id = $temp->order_id;
        $quntity = $temp->quntity;
        $sp_id = $temp->sp_id;
        $tc_type = $temp->tc_type;
        $user_email = $temp->user_email;
        $item_img = $temp->item_img;
       
        
        echo $qu="insert into food_order (item_img,item_name,item_price,order_id,quntity,sp_id,tc_type,user_email) values ('$item_img','$item_name','$item_price','$order_id','$quntity','$sp_id','$tc_type','$user_email')";
        
        $con->Query($qu);
        
    }

  
    echo "Success Registration"

?>
