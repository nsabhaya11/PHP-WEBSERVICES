<?php
    
    
    $con=new mysqli("localhost","root","","tifflunbox");
    
    
        $name=$_POST['user_name'];
        $emil=$_POST['user_email'];
        $password=$_POST['user_password'];
    
        
        
        
       echo $qu="insert into Ragistration(user_name,user_email,user_password) 	values('$name','$emil','$password')";
        //$qu="delete from student where name=bb";
        $con->query($qu);
        echo "success";
        //echo "<script>alert('Operation completed successfully')</script>";
        

?>


