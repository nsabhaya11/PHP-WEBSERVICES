<?php
    
    $con=new mysqli("localhost","root","","tifflunbox");

    
    
    $order_id=$_POST['order_id'];
    $sp_id=$_POST['sp_id'];
    $user_email=$_POST['user_email'];
    $totalbill=$_POST['totalbill'];
    $datetime=$_POST['datetime'];
    $status=$_POST['status'];
    $Street_address=$_POST['Street_address'];
    $city=$_POST['city'];
    $state=$_POST['state'];
    $Pincoad=$_POST['Pincoad'];
    $phno=$_POST['phno'];
    

    
    
    echo $qu="insert into food_order_detail(order_id,sp_id,user_email,totalbill,datetime,status,Street_address,city,state,Pincoad,phno) 	values('$order_id','$sp_id','$user_email','$totalbill','$datetime','$status','$Street_address','$city','$state','$Pincoad','$phno')";
    
    
    $con->query($qu);
    echo "success";
    
    
    ?>
