<?php
    
    $con=new mysqli("localhost","root","","tifflunbox");
    define('UPLOAD_DIR', 'sp_img/');
    
    
    $id=$_POST['sp_id'];
    
 
    
     $qu="select * from sp_ragistration where sp_id='$id'";
    
    
    $con->query($qu);
    echo "success";
    
    
    ?>
