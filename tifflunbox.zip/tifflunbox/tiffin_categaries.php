<?php
    
    $con=new mysqli("localhost","root","","tifflunbox");
   
    $sp_id=$_POST['sp_id'];
    $tc_type=$_POST['tc_type'];
   
    
    $sel="select * from tiffin_categaries where sp_id='$sp_id' and tc_type='$tc_type'";
    $qe=$con->query($sel);
    $nm=$qe->num_rows;
    if($nm>0)
    {
        $dd=array("error"=>"alrady exist..");
        echo json_encode($dd);
        
    }
    else
    {
        echo $qu="insert into tiffin_categaries(sp_id,tc_type) 	values('$sp_id','$tc_type')";
        
        
        $con->query($qu);
        echo "success";
    }
    
    
    
    ?>
