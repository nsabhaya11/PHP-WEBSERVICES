<?php
    
    $con=new mysqli("localhost","root","","tifflunbox");
    
  //  $tc_type = $_POST['tc_type'];
    
    
    
    $qu="SELECT * FROM sp_ragistration";
    
    $pp=$con->query($qu);
    
    while($ff=$pp->fetch_object())
    {
        $qq[]=$ff;
    }
    echo json_encode($qq);
    
    
    ?>
