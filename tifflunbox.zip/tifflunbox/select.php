<?php
    
    $con=new mysqli("localhost","root","","tifflunbox");
    
    $email = $_POST['user_email'];
    $password = $_POST['user_password'];
    
    
    $qu="SELECT * FROM Ragistration WHERE user_email='$email' and user_password='$password'";
    
    $pp=$con->query($qu);
    
    while($ff=$pp->fetch_object())
    {
        $qq[]=$ff;
    }
    echo json_encode($qq);
    
    
    ?>
