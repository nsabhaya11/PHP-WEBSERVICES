
<?php
    
    $con=new mysqli("localhost","root","","tifflunbox");
    
    $id=$_POST['sp_id'];
    
    
    
    $qu="SELECT * FROM user_msg WHERE sp_id='$id'";
    
    $pp=$con->query($qu);
    
    while($ff=$pp->fetch_object())
    {
        $qq[]=$ff;
    }
    echo json_encode($qq);
    
    
    ?>
