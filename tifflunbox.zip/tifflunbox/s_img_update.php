?php

$con=new mysqli("localhost","root","","tifflunbox");

$sp_id = $_POST['sp_id'];
$img_id=$_POST['img_id'];


$qu="SELECT * FROM images WHERE sp_id='$sp_id' and img_id='$img_id'";

$pp=$con->query($qu);

while($ff=$pp->fetch_object())
{
    $qq[]=$ff;
}
echo json_encode($qq);


?>
