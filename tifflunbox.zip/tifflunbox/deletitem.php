<?php
    
    $con=new mysqli("localhost","root","","tifflunbox");
   ;
    
    $item_id=$_POST['item_id'];
    $sp_id=$_POST['sp_id'];
    $tc_type=$_POST['tc_type'];
   

    echo $qu="DELETE FROM `tiffin_items` WHERE  item_id='$item_id' and tc_type='$tc_type' and sp_id='$sp_id'";
   
    
    $con->query($qu);
    echo "success";
    
    
    ?>
