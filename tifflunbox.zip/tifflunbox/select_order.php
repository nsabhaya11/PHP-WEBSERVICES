<?php
    
    $con=new mysqli("localhost","root","","tifflunbox");
    
    $sp_id = $_POST['sp_id'];
    $status= $_POST['status'];

    
    
    
    $qu="SELECT * FROM food_order_detail WHERE sp_id='$sp_id' and  status='$status' group by order_id";
    
    $pp=$con->query($qu);
    
    while($ff=$pp->fetch_object())
    {
        $qq[]=$ff;
    }
    echo json_encode($qq);
    
    
    ?>
