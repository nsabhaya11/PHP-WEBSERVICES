<?php
    
    $con=new mysqli("localhost","root","","tifflunbox");
    
    
    $del_email=$_POST['del_email'];
    $del_password=$_POST['del_password'];
    
    $sel="select * from D_registraion where del_email='$del_email'";
    $qe=$con->query($sel);
    $nm=$qe->num_rows;
    if($nm>0)
    {
        $dd=array("error"=>"alrady exist..");
        echo json_encode($dd);
        
    }
    else
    {
        echo $qu="insert into D_registraion(del_email,del_password) 	values('$del_email','$del_password')";
        
        
        $con->query($qu);
        echo "success";
    }
    
    ?>





