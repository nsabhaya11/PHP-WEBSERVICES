<?php
    
    $con=new mysqli("localhost","root","","tifflunbox");

    
    
    $order_id=$_POST['order_id'];
    $sp_id=$_POST['sp_id'];
    $status=$_POST['status'];
    
    
    echo $qu="UPDATE food_order_detail SET status='$status' WHERE sp_id='$sp_id' and order_id='$order_id'";
    
    
    $con->query($qu);
    echo "success";
    
    
    ?>




